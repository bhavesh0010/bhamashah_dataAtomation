import os,sys,pdb
import subprocess
import time
import csv
import psycopg2
os.chdir("/home/praveen/php_file/php-amazon-mws-reports-master/src/MarketplaceWebService/Samples")
reports = ["_GET_FBA_FULFILLMENT_CUSTOMER_RETURNS_DATA_","_GET_FBA_FULFILLMENT_CURRENT_INVENTORY_DATA_","_GET_AMAZON_FULFILLED_SHIPMENTS_DATA_"]
#filename = ["RETURN", "INVENTRY", "SHIPMENT"]
for x in reports:
    print(x)
    requestId = subprocess.Popen("php /home/praveen/php_file/php-amazon-mws-reports-master/src/MarketplaceWebService/Samples/RequestReportSample.php {}".format(x), shell=True, stdout=subprocess.PIPE)
    rId = requestId.stdout.read()
    print(rId)
    time.sleep(300)
    statusAndId = subprocess.Popen("php /home/praveen/php_file/php-amazon-mws-reports-master/src/MarketplaceWebService/Samples/GetReportRequestListSample.php {}".format(rId), shell=True, stdout=subprocess.PIPE)
    StsId = statusAndId.stdout.read()
    print(StsId)
    status,Id = StsId.split(",")[0], StsId.split(",")[1]
    print(status)
    print(Id)
    result = subprocess.Popen("php /home/praveen/php_file/php-amazon-mws-reports-master/src/MarketplaceWebService/Samples/GetReportSample.php {}".format(Id), shell=True, stdout=subprocess.PIPE)
    data = result.stdout.read()
    print(data) 
    while status == '_DONE_':
        print("DONE")
        result = subprocess.Popen("php /home/praveen/php_file/php-amazon-mws-reports-master/src/MarketplaceWebService/Samples/GetReportSample.php {}".format(Id), shell=True, stdout=subprocess.PIPE)
        data = result.stdout.read()
        print(data)
        data = data.split('\r\n')
        break
        if status == '_IN_PROGRESS_':
            if status == '_DONE_NO_DATA':
                print("Sorry!!! no data found")
            elif status == '_CANCELLED_':
                print("SRY Report CANCELLED")
            else:
                print("Sorry!!!!")
                break
        else:
            time.sleep(180)
            statusAndId = subprocess.Popen("php /home/praveen/php_file/php-amazon-mws-reports-master/src/MarketplaceWebService/Samples/GetReportRequestListSample.php {}".format(rId), shell=True, stdout=subprocess.PIPE)
            StsId = statusAndId.stdout.read()
            print(StsId)  
    if x == '_GET_FBA_FULFILLMENT_CUSTOMER_RETURNS_DATA_':
        with open('/tmp/fbaReturn.csv', 'w') as csvFile:
            writer = csv.writer(csvFile)
            items = []
            #data = data.split('\r\n')
            for i, item in enumerate(data):
                item = item.replace(',',';')
                item = item.split('\t')
                items.append(item)
            writer.writerows(items)
            csvFile.close()
    elif x == '_GET_FBA_FULFILLMENT_CURRENT_INVENTORY_DATA_':
        with open('/tmp/fbaInv.csv', 'w') as csvFile:
            writer = csv.writer(csvFile)
            items = []
            #data = data.split('\r\n')
            for i, item in enumerate(data):
                item = item.replace(',',';')
                item = item.split('\t')
                items.append(item)
            writer.writerows(items)
            csvFile.close()
    elif x == '_GET_AMAZON_FULFILLED_SHIPMENTS_DATA_':
        with open('/tmp/fbaOrder.csv', 'w') as csvFile:
            writer = csv.writer(csvFile)
            items = []
                #data = data.split('\r\n')
            for i, item in enumerate(data):
                item = item.replace(',',';')
                item = item.split('\t')
                items.append(item)
            writer.writerows(items)
            csvFile.close()        
    else:
        print("Invalid Report Type!!!!")
        break        
try:
    connect_str = "dbname='test' user='voylla' host='localhost' password='1234'"
             
    # use our connection values to establish a connection
    conn = psycopg2.connect(connect_str)
    # create a psycopg2 cursor that can execute queries
    cursor = conn.cursor()
    # create a new table with a single column called "name"
    cursor.execute(" DROP TABLE IF EXISTS tmp_fba_return;")
    cursor.execute(" CREATE TABLE tmp_fba_return( return_date timestamp, order_id VARCHAR(25), sku VARCHAR(18), asin VARCHAR(25), fnsku VARCHAR(25), product_name TEXT, quantity INTEGER, fulfillment_center_id VARCHAR(5), detailed_disposition VARCHAR(25), reason VARCHAR(255), license_plate_number VARCHAR(64), customer_comments TEXT);")
    cursor.execute(" COPY tmp_fba_return FROM '/tmp/fbaReturn.csv' delimiter ',' csv header;")           
    cursor.execute(" DROP TABLE IF EXISTS tmp_fba_inv;")
    cursor.execute(" CREATE TABLE tmp_fba_inv( snapshot_date timestamp without time zone, fnsku VARCHAR(16),sku VARCHAR(16),product_name TEXT,quantity SMALLINT, fulfillment_center_id VARCHAR(8), detailed_disposition VARCHAR(32), countrytitle VARCHAR(8) );")
    cursor.execute(" COPY tmp_fba_inv FROM '/tmp/fbaInv.csv' delimiter ',' csv header;")
    cursor.execute(" DROP TABLE IF EXISTS tmp_fba_order;")
    cursor.execute("CREATE TABLE tmp_fba_order(amazon_order_id VARCHAR(32), merchant_order_id VARCHAR(32), shipment_id VARCHAR(32), shipment_item_id VARCHAR(132), amazon_order_item_id VARCHAR(32), merchant_order_item_id VARCHAR(32), purchase_date VARCHAR(32), payments_date VARCHAR(32), shipment_date VARCHAR(32), reporting_date VARCHAR(32), buyer_email VARCHAR(80), buyer_name VARCHAR(325), buyer_phone_number VARCHAR(32), sku VARCHAR(32), product_name Text, quantity_shipped INTEGER, currency VARCHAR(5), item_price NUMERIC, item_tax NUMERIC, shipping_price NUMERIC, shipping_tax NUMERIC, gift_wrap_price NUMERIC, gift_wrap_tax NUMERIC, ship_service_level VARCHAR(32), recipient_name TEXT, ship_address_1 TEXT, ship_address_2 TEXT, ship_address_3 TEXT, ship_city VARCHAR(80), ship_state VARCHAR(80), ship_postal_code VARCHAR(100), ship_country VARCHAR(5), ship_phone_number VARCHAR(32), bill_address_1 TEXT, bill_address_2 TEXT, bill_address_3 TEXT, bill_city VARCHAR(80), bill_state VARCHAR(80), bill_postal_code VARCHAR(10), bill_country VARCHAR(5), item_promotion_discount NUMERIC, ship_promotion_discount NUMERIC, carrier VARCHAR(32), tracking_number VARCHAR(32), estimated_arrival_date VARCHAR(32), fulfillment_center_id VARCHAR(32), fulfillment_channel VARCHAR(32), sales_channel VARCHAR(32) );")
    cursor.execute(" COPY tmp_fba_order FROM '/tmp/fbaOrder.csv' delimiter ',' csv header;")
    # run a SELECT statement - no data in there, but we can try it
    cursor.execute("SELECT * from tmp_fba_order")
    cursor.execute(" SELECT amazon_order_id, merchant_order_id, shipment_id, shipment_item_id, amazon_order_item_id, merchant_order_item_id,REPLACE( SUBSTRING(purchase_date FROM 1 FOR 19), 'T', ' ')::timestamp,REPLACE( SUBSTRING(payments_date FROM 1 FOR 19), 'T', ' ')::timestamp,REPLACE( SUBSTRING(shipment_date FROM 1 FOR 19), 'T', ' ')::timestamp,REPLACE( SUBSTRING(reporting_date FROM 1 FOR 19), 'T', ' ')::timestamp,buyer_email, buyer_name, buyer_phone_number, sku,product_name, quantity_shipped, currency, item_price, item_tax, shipping_price, shipping_tax,gift_wrap_price, gift_wrap_tax, ship_service_level, recipient_name, ship_address_1, ship_address_2,ship_address_3, ship_city, ship_state, ship_postal_code, ship_country, ship_phone_number, bill_address_1, bill_address_2, bill_address_3, bill_city, bill_state, bill_postal_code, bill_country,item_promotion_discount, ship_promotion_discount, carrier, tracking_number, estimated_arrival_date,fulfillment_center_id, fulfillment_channel, sales_channel, NULL, NULL, NULL, 'AFN' FROM tmp_fba_order as tfo WHERE NOT EXISTS( SELECT amazon_order_id FROM tmp_fba_order AS of WHERE tfo.amazon_order_id||tfo.sku||tfo.quantity_shipped = of.amazon_order_id||of.sku||of.quantity_shipped );")
    rows = cursor.fetchall()
    print(rows)
    conn.commit()
except Exception as e:
    print("Uh oh, can't connect. Invalid dbname, user or password?")
    print(e)