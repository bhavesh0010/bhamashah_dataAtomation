Use Bhamashah API to automate the data


OTHERWISE config.inc will occure


use call.py script to execute API and do some changes in the call.py may required according to system


